import React from 'react';
import { Router, Switch, Route } from "react-router-dom";
import logo from './logo.svg';
import NavBar from './component/navbar';
import Counters from './component/counters';
import Tab from './component/tab';
import Login from './component/login';
import Hello from './component/hello';
import Dashboard from './component/Dashboard';
import Redirct from './component/redirct';
import Chart from './component/chart';
import history from './component/history';
//import { BrowserRouter, Route, } from 'react-router-dom'
import './App.css';


function App() {
  return (
    <Router history={history}>
    <Switch>
        <Route path="/" exact component={Tab} />
        <Route path="/hello" component={Hello} />
        <Route path="/Dashboard" component={Dashboard} />
        <Route path="/Login" component={Login} />
    </Switch>
</Router>
    // <React.Fragment>
    // <main className="container">
    //   <Chart/>
    //   {/* <Redirct/> */}
    //  {/* <Hello/>  */}
     
    // {/* <Dashboard/> */}
    //   {/* <Counters/>  */}
    //   <BrowserRouter>
    //   <switch>
    //     {/* <Route path="/" component={Hello} exact/> */}
    //     {/* <Route path="/department" component={Dashboard} exact/> */}
    //     </switch>
    //    </BrowserRouter>
    // </main>
    // </React.Fragment>
   
  );
}

export default App;
