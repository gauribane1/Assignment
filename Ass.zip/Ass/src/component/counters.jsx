import React, { Component } from 'react';
import Counter from './counter';
import { useHistory } from 'react-router-dom';



class counters extends Component {
    state = { 
        counters:[
            {id:1,value:4},
            {id:2,value:8},
            {id:3,value:3},
            {id:4,value:7},
            {id:5,value:9}
        ]
     }
   
    render() { 
        return ( 
                
                <div>
                    <button onClick={this.nextPage}>Next</button>
                    <button onClick={this.handleReset}>Reset</button>
                    {this.state.counters.map(data=><Counter key={data.id} value={data.value} id={data.id}
                    onDelete={this.handleDelete}
                    selected={true}/> )}
                </div>  
           
         );
    }
    handleReset=()=>{
        const counters=this.state.counters.map(c=> {
            c.value=0;
            return c;
        });
        this.setState({counters});
    };
    nextPage=()=>{
        const history = useHistory();
        history.push("/hello");
       // browserHistory.push("/hello");
        //browserHistory.push('/hello')
       // this.context.router.history.push('/hello')
        //this.props.history.push("/EnquiryResult");
            
       // this.props.history.push("/");
    }
    handleIncrement=counter=>{
        const counters=[...this.state.counters];
        const index=counters.indexOf(counter);
        counters[index]={...counter};
        counters[index].value++;
        this.setState({counters});
       

    }
    handleDelete=(counterId)=>{
        const counterData=this.state.counters.filter(c=>c.id!=counterId);
        this.setState({
            counters:counterData
        });
        //alert("Reach");
        console.log("Handle Delete",counterId); 
    }
}
 
export default counters;