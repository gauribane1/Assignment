import React from 'react';
import {Bar} from 'react-chartjs-2';
import {Line} from 'react-chartjs-2';
import {Pie, Doughnut} from 'react-chartjs-2';
import { Button } from 'react-bootstrap';
import history from './history';

const state = {
  labels: ['January', 'February', 'March',
           'April', 'May'],

  datasets: [
        {
          label: 'Rainfall',
          backgroundColor: [
            '#B21F00',
            '#C9DE00',
            '#2FDE00',
            '#00A6B4',
            '#6800B4'
          ],
          hoverBackgroundColor: [
          '#501800',
          '#4B5000',
          '#175000',
          '#003350',
          '#35014F'
          ],
          data: []
        }
  ]
}

export default class App extends React.Component {
  constructor(props)
  {
    super(props);
    this.state={
     inputes:[]
     
     
    }
  }
  componentDidMount()
  {
     console.log(this.state.datasets)
  }
  render() {
    return (
        <div>
           <form>
            <Button variant="btn btn-success" onClick={() => history.push('./hello')}>Click button to view products</Button>
          </form>
      <div style={{width:"50%",display: "flex"}}>
          <div style={{width:"50%"}}>
                <Bar
                data={this.state.datasets}
                options={{
                    title:{
                    display:true,
                    text:'Average Rainfall per month',
                    fontSize:20
                    },
                    legend:{
                    display:true,
                    position:'right'
                    }
                }}
                />
        </div>
         
        <div style={{width:"50%"}}>
                <Line
                data={this.state.datasets}
                options={{
                    title:{
                    display:true,
                    text:'Average Rainfall per month',
                    fontSize:20
                    },
                    legend:{
                    display:true,
                    position:'right'
                    }
                }}
                />
        </div>
        </div>
        <div style={{width:"50%",display: "flex",marginTop:"10%"}}>
        <div style={{width:"50%"}}>
                <Pie
                data={this.state.datasets}
                options={{
                    title:{
                    display:true,
                    text:'Average Rainfall per month',
                    fontSize:20
                    },
                    legend:{
                    display:true,
                    position:'right'
                    }
                }}
                />
          </div>

          <div style={{width:"50%"}}>
                <Doughnut
                data={this.state.datasets}
                options={{
                    title:{
                    display:true,
                    text:'Average Rainfall per month',
                    fontSize:20
                    },
                    legend:{
                    display:true,
                    position:'right'
                    }
                }}
                />
            </div>
                </div>
       
      
        </div>
    );
  }
}