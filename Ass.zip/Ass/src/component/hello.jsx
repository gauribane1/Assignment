import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';

import { BrowserRouter, Route, } from 'react-router-dom'
import UserList from './Dashboard'
import history from './history';
//import {Redirect, Route} from 'react-router-dom';


class Hello extends Component {
constructor(props){
    super(props);
    this.state={
        username:'',
        password:'',
        toDashboard: false
    }
 }

 handleClick=(event)=>{
   //Handle login
  const requestOptions = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 
      bo_and_pro_users_email:this.state.username,
      bo_and_pro_users_password:this.state.password
    })
};
fetch('http://13.58.72.248:3002/gyggs_api/business_pro_data/login', requestOptions)
    .then(response => response.json())
    .then(data => {
      if(data.status=="failure") {
       alert("Invalid username & password");
      }
      else
      {
        this.setState({
          toDashboard:true
        });
        localStorage.removeItem('userLoginObject');
        localStorage.setItem('userLoginObject', JSON.stringify(data));
        history.push('/');
      }
    });
  }
render() {
   return (
    <div>
      {this.state.toDashboard?(<BrowserRouter>
        <Route path="/department" component={UserList}/>
       </BrowserRouter>):"Incorect route"}
     <MuiThemeProvider>
          <div>
          <AppBar
             title="Login"
           />
           <div style={{marginLeft:"45%",marginTop:"40px"}}>
                <TextField
                    hintText="Enter your Username"
                    floatingLabelText="Username"
                    onChange = {(event,newValue) => this.setState({username:newValue})}
                    />
                <br/>
                    <TextField
                    type="password"
                    hintText="Enter your Password"
                    floatingLabelText="Password"
                    onChange = {(event,newValue) => this.setState({password:newValue})}
                    />
                  <br/>
               <RaisedButton label="Login" primary={true} style={style} onClick={(event) => this.handleClick(event)}/>
             </div>
         </div>
         </MuiThemeProvider>
      </div>
    );
  }
}
const style = {
 margin: 15,
};
export default Hello;