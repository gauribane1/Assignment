import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';

  
class Dashboard extends Component {
    componentWillMount() {
      //get data from local storage
          var retrievedObject =JSON.parse(localStorage.getItem('userLoginObject'));
          this.setState({
                userName:retrievedObject.bo_and_pro_users_firstname + " "+ retrievedObject.bo_and_pro_users_lastname
          });

        fetch("http://dummy.restapiexample.com/api/v1/employees")
          .then(res => res.json())
          .then(
            (result) => {
               this.setState({
                isLoaded: true,
                items: result.data,
                
              });
            },
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
      }
    state = { 
        isLoaded:false,
        items:[],
        userName:null
     }
    handleLogoutClick=(event)=>{
        localStorage.removeItem('userLoginObject');
    }
    render() { 
      
        return (
          <div>
            {this.state.isLoaded?
             (
              <div>
                 <MuiThemeProvider>
                  <div>
                   <AppBar
                      title={this.state.userName}
                  />
                   <RaisedButton label="LogOut" primary={true} style={style} onClick={(event) => this.handleLogoutClick(event)}/>
                  <div style={{marginLeft:"45%",marginTop:"40px"}}>
                        <ul>
                            {this.state.items.map(item => (
                            <li key={item.id}>
                              {item.employee_name}  {item.employee_salary}
                            </li>
                            ))}
                        </ul>
                  </div>
               
                </div>
              </MuiThemeProvider>
              </div>
             )
           :"Data not found."}
        </div>
          
        );
    }
}
const style = {
   margin: 15,
   position:'absolute',
   right:0
 };
export default Dashboard;


