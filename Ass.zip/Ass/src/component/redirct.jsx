import React, { Component } from 'react';
import { BrowserRouter, Route, } from 'react-router-dom'
import UserList from './Dashboard'
class redirct extends Component {
 

  render() {
    return (
      <BrowserRouter>
        <Route path="/" component={UserList}/>
       </BrowserRouter>
    )
  }
}
export default redirct;