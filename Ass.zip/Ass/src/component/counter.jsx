import React, { Component } from 'react';
class Counter extends Component {
    state = { 
       count:this.props.value,
       arr:["New1","New2","New3","New4"],

        userName:"",
        password:""
     };
    // constructor(){
    //    super();
    //   this.handleClick=this.handleClick.bind(this);
    // };
     renderArrayElement()
     {
         if(this.state.arr.length==0) return <h1>No Element Found</h1>;
         return   <ul>{this.state.arr.map(data=><li key={data}>{data}</li>)}</ul>;
     }
     
   
    render() { 
        return (
            <div>
                <span style={{color:"white",marginRight:"12px",marginLeft:"30px",backgroundColor:"blue",borderRadius:"5px"}}>{this.showValue()}</span>
          
                 <button onClick={()=>this.handleClick()}>Increment</button> 
                

                <button style={{backgroundColor:'red',width:"80px"}} 
                onClick={()=>this.props.onDelete(this.props.id)}>Delete</button>
                {/* <div>
                    {this.renderArrayElement()}
                </div> */}
                {/* {this.state.arr.length==0 && "Please"}
                <div>
                    <input type="text" name={this.state.userName}></input>
                    <input type="password" name={this.state.password}></input>
                    <button onClick={this.loginForm()}></button>
                </div> */}
            </div>
        );
    }
    showValue()
    {
         const {count} = this.state;
        return count===0?"Zero":count;
        
    }
    handleClick()
    {
     
       this.setState({count:this.state.count+1});
    
    };
    loginForm()
    {
        alert(this.state.userName);
        //console.log(this.state.userName,this.state.password);
    }
}
 
export default Counter;